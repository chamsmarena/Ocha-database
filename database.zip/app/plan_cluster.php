<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class plan_cluster extends Model
{
    //
}
