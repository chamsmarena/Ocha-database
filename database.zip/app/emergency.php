<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class emergency extends Model
{
    //
    protected $primaryKey = 'emergency_id';
    public $incrementing = false;
}
