<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class methodedecalcul extends Model
{
    //
    protected $primaryKey = 'id_method';
    public $incrementing = false;
}
