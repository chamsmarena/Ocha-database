<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class type_header extends Model
{
    //
    protected $primaryKey = 'type_header_id';
    public $incrementing = false;
}
