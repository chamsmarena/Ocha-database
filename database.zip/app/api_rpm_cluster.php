<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class api_rpm_cluster extends Model
{
    //
}
