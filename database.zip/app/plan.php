<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class plan extends Model
{
    //
    protected $primaryKey = 'plan_rowid';
    public $incrementing = false;
}
