<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class header extends Model
{
    //
    protected $primaryKey = 'header_id';
    public $incrementing = false;
}
