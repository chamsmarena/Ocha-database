<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class category_emergency extends Model
{
    //
    protected $primaryKey = 'emerg_categ_id';
    public $incrementing = false;
}
