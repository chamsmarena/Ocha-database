<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sub_strategic_objective extends Model
{
    //
}
