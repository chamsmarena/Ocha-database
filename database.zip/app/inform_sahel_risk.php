<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class inform_sahel_risk extends Model
{
    //
    protected $primaryKey = 'id_inform';
    protected $fillable = ['id_inform'];
    public $incrementing = false;
}
