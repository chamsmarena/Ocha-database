<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class fts_flow extends Model
{
    //
    protected $primaryKey = 'flow_rowid';
    public $incrementing = false;

}
