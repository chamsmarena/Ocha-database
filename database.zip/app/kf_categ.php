<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kf_categ extends Model
{
    //
    protected $primaryKey = 'kfcateg_id';
    public $incrementing = false;
}
