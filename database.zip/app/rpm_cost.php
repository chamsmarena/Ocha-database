<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rpm_cost extends Model
{
    //
}
