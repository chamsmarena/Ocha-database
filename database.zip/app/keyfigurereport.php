<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class keyfigurereport extends Model
{
    //
    protected $connection = 'mysql2';
}
