<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class keyfigureindicatordetail extends Model
{
    //
    protected $connection = 'mysql2';
}
