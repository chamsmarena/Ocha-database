<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class file extends Model
{
    //
    protected $primaryKey = 'file_id';
    public $incrementing = false;
}
