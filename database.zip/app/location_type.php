<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class location_type extends Model
{
    //
    protected $primaryKey = 'locationtype_id';
    public $incrementing = false;
}
