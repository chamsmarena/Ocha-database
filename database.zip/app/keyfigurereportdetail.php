<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class keyfigurereportdetail extends Model
{
    //
    protected $connection = 'mysql2';
}
