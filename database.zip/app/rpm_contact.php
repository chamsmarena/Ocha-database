<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rpm_contact extends Model
{
    //
}
