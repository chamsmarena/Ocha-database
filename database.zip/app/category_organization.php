<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class category_organization extends Model
{
    //
    protected $primaryKey = 'organization_categories_id';
}
