<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class disaggregation extends Model
{
    //
    protected $primaryKey = 'id_disaggregation';
    public $incrementing = false;
    
}
