<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class plan_cluster_activity extends Model
{
    //
}
