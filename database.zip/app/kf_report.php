<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kf_report extends Model
{
    //
    protected $primaryKey = 'kfreport_id';
    public $incrementing = false;
}
