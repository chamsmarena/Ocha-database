<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cluster_activity extends Model
{
    //
}
