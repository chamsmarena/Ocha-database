<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class location_other extends Model
{
    //
    protected $primaryKey = 'location_other_id';
    public $incrementing = false;
}
