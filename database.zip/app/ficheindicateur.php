<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ficheindicateur extends Model
{
    //
    protected $primaryKey = 'kfind_id';
    public $incrementing = false;
}
