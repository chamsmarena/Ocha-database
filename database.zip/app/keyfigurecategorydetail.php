<?php

namespace App;




use Illuminate\Database\Eloquent\Model;

class keyfigurecategorydetail extends Model
{
    //
    protected $connection = 'mysql2';
    
}
