<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class keyfiguresubcategory extends Model
{
    //
    protected $connection = 'mysql2';
}
