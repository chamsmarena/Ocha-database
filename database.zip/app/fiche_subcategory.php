<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class fiche_subcategory extends Model
{
    //
    protected $primaryKey = 'kfsubcategory_id';
    public $incrementing = false;
}
