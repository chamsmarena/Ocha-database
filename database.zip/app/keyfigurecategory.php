<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kf_category extends Model
{
    //
    protected $connection = 'mysql2';
 
}
