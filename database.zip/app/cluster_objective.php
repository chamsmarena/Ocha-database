<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cluster_objective extends Model
{
    //
}
