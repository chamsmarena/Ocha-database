<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class categories_plan extends Model
{
    //
    protected $primaryKey = 'plan_categorie_id';
    public $incrementing = false;

}
