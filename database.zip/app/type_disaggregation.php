<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class type_disaggregation extends Model
{
    //
    protected $primaryKey = 'id_type_disaggregation';
    public $incrementing = false;

    
}
