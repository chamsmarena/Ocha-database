<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class keyfigureindicator extends Model
{
    //
    protected $connection = 'mysql2';
}
