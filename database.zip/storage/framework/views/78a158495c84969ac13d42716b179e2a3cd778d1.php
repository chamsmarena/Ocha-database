<?php $__env->startSection('title', 'Confirm data import'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col">
        <div class="row">
            <div class="col">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item " aria-current="page"><a href="/database">Database</a></li>
                        <li class="breadcrumb-item " aria-current="page"><a href="/import">Import screen</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Confirm data import</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="row">
            <div class="col">
                Are you sure you want to import <strong><?php echo e($elementName); ?> </strong> data? old data will be replaced.

                    <?php if(Session::has('msg')): ?>
                        <div class="alert alert-danger" role="alert">
                        <?php echo Session::has('msg') ? Session::get("msg") : ''; ?>

                    </div>
                    <?php endif; ?>

            
                <form action="/database/guide_import" method="POST">
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="import">Type "IMPORT" in all caps to confirm</label>
                        <input type="text" class="form-control w-25" id="import"  name="import" autocomplete="off">

                    </div>
                    <input type="text" hidden name="element" value="<?php echo e($element); ?>">
                    <button type="submit" class="btn btn-primary" style="background-color:#418fde;border:none;">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\database\resources\views/localdata/confirmimport.blade.php ENDPATH**/ ?>