<?php $__env->startSection('title', $datas->zone_name); ?>
<?php $__env->startSection('content'); ?>

    <div class="col">
        <div class="row">
            <div class="col">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item"><a href="/database">Database</a></li>
                        <li class="breadcrumb-item"><a href="/managezones">Manage crisis zones</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($datas->zone_name); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
        
        <div class="row">
            <div class="col">
            <p><em>Liste des localités dans le <strong><?php echo e($datas->zone_name); ?></strong></em></p>
            </div>
        </div>
        <div class="row">
            <div class="col">
            <p><em><a href="/edit/zone/<?php echo e($datas->zone_id); ?>">Editer</a> ou <a href="/add/localite/<?php echo e($datas->zone_id); ?>">Supprimer la zone</a>, <a href="/add/localite/<?php echo e($datas->zone_id); ?>">Ajouter localité dans la zone</a></em></p>
            </div>
        </div>
        <br/>
        <div class="row">
            <div class="col">
                <?php $__currentLoopData = $liste_localites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/managelocalite/<?php echo e($localite->local_id); ?>" class="btn btn-light" role="button" aria-pressed="true"><?php echo e($localite->local_name); ?> (<?php echo e($localite->local_pcode); ?>, admin <?php echo e($localite->local_admin_level); ?>)</a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>           
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\database\resources\views/zone/manageconsulter.blade.php ENDPATH**/ ?>