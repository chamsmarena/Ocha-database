<?php $__env->startSection('title', 'Edit '.$datas->local_name); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="col">
        <div class="row">
            <div class="col">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item"><a href="/database">Database</a></li>
                        <li class="breadcrumb-item"><a href="/managezones">Manage crisis zones</a></li>
                        <li class="breadcrumb-item"><a href="/managezone/<?php echo e($zone[0]->zone_id); ?>"><?php echo e($zone[0]->zone_name); ?></a></li>
                        <li class="breadcrumb-item active" aria-current="page">Edit <?php echo e($datas->local_name); ?></li>
                    </ol>
                </nav>
            </div>
        </div>


        <div class="row">
            <div class="col">
                <form action="/update/localite" method="POST">
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="zone_code">Name</label>
                        <input type="text" class="form-control" id="local_name"  name="local_name" aria-describedby="zone_codeHelp" value="<?php echo e($datas->local_name); ?>" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label for="zone_name">Pcode</label>
                        <input type="text" class="form-control" id="local_pcode" name="local_pcode" aria-describedby="zone_nameHelp"  value="<?php echo e($datas->local_pcode); ?>" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label for="local_admin_level">Admin level</label>
                        <select class="form-control" id="local_admin_level" name="local_admin_level">
                            <option value="0" <?php echo ($datas->local_admin_level==0) ? "selected='selected'" : ""; ?>>0</option>
                            <option value="1" <?php echo ($datas->local_admin_level==1) ? "selected='selected'" : ""; ?>>1</option>
                            <option value="2" <?php echo ($datas->local_admin_level==2) ? "selected='selected'" : ""; ?>>2</option>
                            <option value="3" <?php echo ($datas->local_admin_level==3) ? "selected='selected'" : ""; ?>>3</option>
                        </select>
                    </div>
                    <input type="text" hidden name="local_id" value="<?php echo e($datas->local_id); ?>">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>

            </div>
        </div>

        
    </div>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\database\resources\views/localite/modifier.blade.php ENDPATH**/ ?>