<?php $__env->startSection('title', 'Authentification screen'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col">
        <div class="row">
            <div class="col">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item " aria-current="page"><a href="/database">Database</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Security</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <img src="<?php echo e(asset('images/shield.png')); ?>" class="rounded mx-auto d-block" alt="logo ocha"/>
            </div>
            <div class="col-12">
                <?php if(Session::has('msg')): ?>
                        <div class="alert alert-danger" role="alert">
                        <?php echo Session::has('msg') ? Session::get("msg") : ''; ?>

                    </div>
                <?php endif; ?>
                <form action="/accessimport" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Enter password for access</label>
                        <input type="password" name="password" class="form-control w-25" id="exampleInputPassword1" placeholder="Password">
                    </div>
                    <button type="submit" class="btn btn-primary" style="background-color:#418fde;border:none;">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\database\resources\views/localdata/accessimport.blade.php ENDPATH**/ ?>