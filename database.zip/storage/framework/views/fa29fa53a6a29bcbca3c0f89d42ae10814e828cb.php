<?php $__env->startSection('title', $datas->local_name); ?>
<?php $__env->startSection('content'); ?>
    <div class="col">
        <div class="row">
            <div class="col">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item"><a href="/database">Database</a></li>
                        <li class="breadcrumb-item"><a href="/managezones">Manage crisis zones</a></li>
                        <li class="breadcrumb-item"><a href="/managezone/<?php echo e($zone[0]->zone_id); ?>"><?php echo e($zone[0]->zone_name); ?></a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($datas->local_name); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <h3><?php echo e($datas->local_name); ?></h3>
                <p><?php echo e($datas->local_pcode); ?> (admin <?php echo e($datas->local_admin_level); ?>)</p>
                <p><em><a href="/edit/localite/<?php echo e($datas->local_id); ?>">Edit</a> or <a href="/delete/localite/<?php echo e($datas->local_id); ?>">Delete</a> the locality</em></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>           
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\database\resources\views/localite/manageconsulter.blade.php ENDPATH**/ ?>