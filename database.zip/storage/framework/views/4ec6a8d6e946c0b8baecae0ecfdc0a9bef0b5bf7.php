<?php $__env->startSection('title', 'Manage crisis zones'); ?>
<?php $__env->startSection('content'); ?>
<div class='col'>
    <div class="row">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="/database">Database</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Manage crisis zones</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class='col'>
            <p><em>Crisis zones in the <strong>West and Central Africa</strong></em></p>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <p><em><a href="/add/zone">Add</a> a new zone</em></p>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/managezone/<?php echo e($data->zone_id); ?>" class="btn btn-light" role="button" aria-pressed="true"><?php echo e($data->zone_name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>



    <!--div class="row">
        <?php if(Session::has('msg')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo Session::has('msg') ? Session::get("msg") : ''; ?>

        </div>
        <?php endif; ?>
    
        <form action="/massdelete/zone" method="POST">
        <?php echo csrf_field(); ?>
            <table class="table table-dark">
                <thead>
                    <tr>
                        <th scope="col">Delete?</th>
                        <th scope="col">Code</th>
                        <th scope="col">Name</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><input type="checkbox" name="checkbox<?php echo e($data->zone_id); ?>" id="checkbox<?php echo e($data->zone_id); ?>"></td>
                        <td><a href='/managezone/<?php echo e($data->zone_id); ?>'><?php echo e($data->zone_code); ?></a></td>
                        <td><a href='/managezone/<?php echo e($data->zone_id); ?>'><?php echo e($data->zone_name); ?></a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="form-group">
                <label for="delete">Type exactly <strong>DELETE multiples</strong> to confirm</label>
                <input type="text" class="form-control" id="delete"  name="delete" >
            </div>
            <button type="submit" class="btn btn-danger">Supprimer</button>
        </form>
    </div-->
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\database\resources\views/zone/manageliste.blade.php ENDPATH**/ ?>